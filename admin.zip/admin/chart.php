<div class="row" style="margin-top: 2%">

	<div class="col-md-12">
	  <!-- LINE CHART -->
	  <div class="info-box">
		<div class="box-body">
		  <div class="chart">
			<canvas id="topSales" style="height:350px"></canvas>
		  </div>
		</div>
		<!-- /.box-body -->
	  </div>
	  <!-- /.box -->

	</div>
	
	<div class="col-md-12">
	  <!-- LINE CHART -->
	  <div class="info-box">
		<div class="box-body">
		  <div class="chart">
			<canvas id="topSalesMonth" style="height:350px"></canvas>
		  </div>
		</div>
		<!-- /.box-body -->
	  </div>
	  <!-- /.box -->

	</div>
	
	
	
	<div class="col-md-12">
	  <!-- LINE CHART -->
	  <div class="info-box">
		<div class="box-body">
		  <div class="chart">
			<canvas id="inventoryChart" style="height:350px"></canvas>
		  </div>
		</div>
		<!-- /.box-body -->
	  </div>
	  <!-- /.box -->

	</div>
	

  </div>
